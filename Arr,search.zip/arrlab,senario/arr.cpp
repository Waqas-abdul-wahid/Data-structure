#include <iostream>
int* createArray(int size);
void insertArray(int *arr, int size, int index, int value);
void deleteFrom(int* arr, int size, int index);
void printArray(int* arr, int size);
int main(){
	int size = 0, value = 0, index = 0;
	char ch = 0;
	
	std::cout << "Enter size of array? ";
	std::cin >> size;
	
	int* arr = createArray(size);
	
	printArray(arr, size);
	
	do{
		std::cout << "Enter the value you want to insert: ";
		std::cin >> value;
		std::cout << "At what index?";
		std::cin >> index;
		insertArray(arr, size, index, value);
		std::cout << "\nAfter Array insertion\n";
		printArray(arr, size);
		std::cout<< "\n\nWould you like to add more? (y/n)";
		std::cin >> ch;
	}while(ch!='n');
	
	
	do{
		std::cout << "Enter the index you want to delete value from?";
		std::cin >> index;
		deleteFrom(arr, size, index);
		std::cout << "\nAfter Array deletion\n";
		printArray(arr, size);
		std::cout<< "\n\nWould you like to delete more? (y/n)";
		std::cin >> ch;
	}while(ch!='n');
	
	
	return 0;
}
int* createArray(int size){
	int* arr = new int[size];
	for(int i=0;i<size;++i)
		arr[i] = 0;
	return arr;
}
void insertArray(int *arr, int size, int index, int value){
	int i=0;
	for(i=size-1;i>index;--i){
		arr[i] = arr[i-1];
	}
	arr[index] = value;
}
void printArray(int* arr, int size){
	std::cout << "The Array is\n";
	for(int i=0;i<size;++i)
		std::cout << "The Array Index "<<i << " is " << arr[i] << "\n";
}
void deleteFrom(int* arr, int size, int index){
	int i=0;
	for(i=index;i<size-1;++i){
		arr[i] = arr[i+1];
	}
}