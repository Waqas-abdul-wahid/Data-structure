#include <iostream>
#include <string>
int* createBookIsbn(int size);
int* createBookTitle(int size);
int* createBookPrice(int size);
void insertArray(int *arr, int size, int index, int value);
void deleteFrom(int* arr, int size, int index);
void printArray(int* arr, int size);
int main(){
	int size = 10, isbn = 0, index = 0, price = 0;
	string title;
	char ch = 0;
	
	
	int* isbn = createBookIsbn(size);
	string* title = createBookTitle(size);
	int* price = createBookPrice(size);
	
	printArray(arr, size);
	
	do{
		std::cout << "Enter the isbn for book you want to insert: ";
		std::cin >> isbn;
		std::cout << "Enter the price for book you want to insert: ";
		std::cin >> price;
		std::cout << "Enter the title for book you want to insert: ";
		std::cin >> title;
		std::cout << "At what index?";
		std::cin >> index;
		insertArray(arr, size, index, value);
		std::cout << "\nAfter Array insertion\n";
		printArray(arr, size);
		std::cout<< "\n\nWould you like to add more? (y/n)";
		std::cin >> ch;
	}while(ch!='n');
	
	
	do{
		std::cout << "Enter the index you want to delete value from?";
		std::cin >> index;
		deleteFrom(arr, size, index);
		std::cout << "\nAfter Array deletion\n";
		printArray(arr, size);
		std::cout<< "\n\nWould you like to delete more? (y/n)";
		std::cin >> ch;
	}while(ch!='n');
	
	
	return 0;
}

int* createBookIsbn(int size){
	int* arr = new int[size];
	for(int i=0;i<size;++i)
		arr[i] = 0;
	return arr;
}
string* createBookTitle(int size){
	string* arr = new string[size];
	for(int i=0;i<size;++i)
		arr[i] = 0;
	return arr;
}
int* createBookPrice(int size){
	int* arr = new int[size];
	for(int i=0;i<size;++i)
		arr[i] = 0;
	return arr;
}


void insertArray(int *arr, int size, int index, int isbn, string title, int price){
	int i=0;
	for(i=size-1;i>index;--i){
		arr[i] = arr[i-1];
	}
	arr[index] = value;
}
void printArray(int* arr, int size){
	std::cout << "The Array is\n";
	for(int i=0;i<size;++i)
		std::cout << "The Array Index "<<i << " is " << arr[i] << "\n";
}
void deleteFrom(int* arr, int size, int index){
	int i=0;
	for(i=index;i<size-1;++i){
		arr[i] = arr[i+1];
	}
}