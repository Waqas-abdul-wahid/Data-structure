#include <iostream>
int search(int* arr, int size, int element){
	for(int i=0;i<size; ++i){
		if(arr[i]==element)
			return i;
	}
	return -1;
}
int binsearch(int* arr, int left, int right, int element){
	while(left<=right){
		int mid = left+right/2;
		if(arr[mid]==element)
			return mid;
		
		else if(arr[mid]<element)
			left = mid+1;
		
		else
			right = mid-1;
	}
	return -1;
}
int main(){
	int size = 10, searchElement = 0, resultIndex = 0;
	int* array = new int[size];
	int number = 1;
	for(int i=0;i<size;++i)
		array[i] = (number++*number)+1;
	
	std::cout << "The Array is:\n";
	for(int i =0; i<size; ++i)
		std::cout << "["<<i<<"] = "<< array[i] << "\n";
	
	std::cout << "\n\nEnter the number you want to search? ";
	std::cin >> searchElement;
	
	resultIndex = binsearch(array, 0, size-1, searchElement);
	
	if(resultIndex==-1)
		std::cout << "not found";
	else 
		std::cout << "Element found at "<<resultIndex;
	
	return 0;
}