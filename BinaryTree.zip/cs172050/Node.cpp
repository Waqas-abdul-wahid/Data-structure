#include"Node.h"
Node::Node(int item)
{
    key=item;
    left=NULL;
    right=NULL;
}