#include<iostream>


struct Node{
    int key;
    Node  *left;
    Node *right;
    Node(int item);
};